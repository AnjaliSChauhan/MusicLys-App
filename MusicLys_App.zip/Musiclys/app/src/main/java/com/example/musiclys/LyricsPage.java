package com.example.musiclys;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class LyricsPage extends AppCompatActivity {
     TextView fullLyrics;
     ImageView fullImg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lyrics_page);

        fullLyrics = (TextView)findViewById(R.id.pLyrics);
        fullImg = (ImageView)findViewById(R.id.LyImage2);
        Bundle mBundle = getIntent().getExtras();

        if(mBundle!= null){
            fullLyrics.setText(mBundle.getString("Lyrics"));
            fullImg.setImageResource(mBundle.getInt("Image"));

        }

    }
}