package com.example.musiclys;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Pdata extends RecyclerView.Adapter<LyricsViewHolder>{

    private Context mContext;
    private List<MusicData> myMusicList;

    public Pdata(Context mContext, List<MusicData> myMusicList) {
        this.mContext = mContext;
        this.myMusicList = myMusicList;
    }

    @Override
    public LyricsViewHolder onCreateViewHolder(@NonNull ViewGroup ViewGroup, int i) {
        View mView = LayoutInflater.from(ViewGroup.getContext()).inflate(R.layout.app_layout , ViewGroup,false);
        return new LyricsViewHolder (mView);
    }

    @Override
    public void onBindViewHolder(@NonNull LyricsViewHolder LyricsViewHolder, int i) {
        LyricsViewHolder.imageView.setImageResource(myMusicList.get(i).getItemImg());
        LyricsViewHolder.mName.setText(myMusicList.get(i).getItemName());
        LyricsViewHolder.mSinger.setText(myMusicList.get(i).getItemSinger());
        LyricsViewHolder.mLyrics.setText(myMusicList.get(i).getItemLyrics());
        LyricsViewHolder.mCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext,LyricsPage.class);
                intent.putExtra("Image",myMusicList.get(LyricsViewHolder.getAdapterPosition()).getItemImg());
                intent.putExtra("Lyrics",myMusicList.get(LyricsViewHolder.getAdapterPosition()).getItemLyrics());
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return myMusicList.size();
    }
}

class LyricsViewHolder extends RecyclerView.ViewHolder {

    ImageView imageView;
    TextView mName, mSinger, mLyrics;
    CardView mCardView;

    public LyricsViewHolder(@NonNull View itemView) {
        super(itemView);
        imageView = itemView.findViewById(R.id.LyImage);
        mName= itemView.findViewById(R.id.LyTitle);
        mSinger = itemView.findViewById(R.id.lySinger);
        mLyrics = itemView.findViewById(R.id.lyLyrics);
        mCardView= itemView.findViewById(R.id.myCardView);
    }
}