package com.example.musiclys;

public class MusicData {
    private String itemName;
    private String itemSinger;
    private String itemLyrics;
    private int itemImg;

    public MusicData(String itemName, String itemSinger, String itemLyrics, int itemImg) {
        this.itemName = itemName;
        this.itemSinger = itemSinger;
        this.itemLyrics = itemLyrics;
        this.itemImg = itemImg;
    }

    public String getItemName() {
        return itemName;
    }

    public String getItemSinger() {
        return itemSinger;
    }

    public String getItemLyrics() {
        return itemLyrics;
    }

    public int getItemImg() {
        return itemImg;
    }
}