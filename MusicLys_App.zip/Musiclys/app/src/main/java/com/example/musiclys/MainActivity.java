package com.example.musiclys;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView mRecyclerView;
    List<MusicData> myMusicList;
    MusicData mMusicData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mRecyclerView= (RecyclerView)findViewById(R.id.recyclerView);
        GridLayoutManager GridLayoutManager = new GridLayoutManager(MainActivity.this,1 );
        mRecyclerView.setLayoutManager(GridLayoutManager);

        myMusicList = new ArrayList<>();
        mMusicData = new MusicData("CIYT LIFE"," Raghav Meattle","I claim to be this person,\n" +
                "Not selfish not greedy well that's not me, it's hard to be\n" +
                "I'd hate to be mistaken for someone not\n" +
                "Needy, well that's just me, it's hard to see\n" + "\n" +
                "I close my eyes in dust bowls called city life\n" +
                "I wonder why we live here and why we haven't left\n" +
                "I close my eyes in narrow lanes and pigsty I\n" +
                "Wonder why I can't see the sky and all the stars\n" + "\n" +
                "While we all chase the love\n" +
                "We all chase the cars\n" +
                "We all chase the good life with broken\n" +
                "Hearts I can sing to the clouds, sing to the rain\n" +
                "It won't mean a thing in these packed trains\n" + "\n" +
                "I close my eyes to begging kids and their cries I\n" +
                "Wonder why I can't see the stone that I've become\n" +
                "I close my eyes to honey bees and butterflies I\n" +
                "Wonder why they fell trees and how they aim to breathe\n" + "\n" +
                "While we all chase the love\n" +
                "We all chase the cars\n" +
                "We all chase the good life with broken hearts\n" +
                "I can sing to the clouds, sing to the rain\n" +
                "It won't mean a thing in these packed trains\n" + "\n" +
                "I claim to be this person,\n" +
                "Not selfish not greedy well that's not me, it's hard to be.", R.drawable.image1);
        myMusicList.add(mMusicData);

        mMusicData = new MusicData("RAINBOW"," Kacey Musgraves","When it rains, it pours\n" +
                "But you didn't even notice it ain't rainin' anymore\n" +
                "It's hard to breathe when all you know is\n" +
                "The struggle of stayin' above the risin' water line\n" + "\n" +
                "Well the sky has finally opened\n" +
                "The rain and wind stopped blowin'\n" +
                "But you're stuck out in the same ol' storm again\n" +
                "You hold tight to your umbrella\n" +
                "Well, darlin', I'm just tryin' to tell ya\n" +
                "That there's always been a rainbow hangin' over your head\n" + "\n" +
                "If you could see what I see, you'd be blinded by the colors\n" +
                "Yellow, red, and orange, and green, and at least a million others\n" +
                "So tie up the bow, take off your coat, and take a look around\n" + "\n" +
                "'Cause the sky has finally opened\n" +
                "The rain and wind stopped blowin'\n" +
                "But you're stuck out in the same ol' storm again\n" +
                "You hold tight to your umbrella\n" +
                "Well, darlin', I'm just tryin' to tell ya\n" +
                "That there's always been a rainbow hangin' over your head\n" + "\n" +
                "Oh, tie up the bow, take off your coat, and take a look around\n" +
                "Everything is alright now\n" + "\n" +
                "'Cause the sky has finally opened\n" +
                "The rain and wind stopped blowin'\n" +
                "But you're stuck out in the same ol' storm again\n" +
                "Let go of your umbrella\n" +
                "'Cause, darlin', I'm just tryin' to tell ya\n" +
                "That there's always been a rainbow hangin' over your head\n" +
                "Yeah, there's always been a rainbow hangin' over your head\n" + "\n" +
                "It'll all be alright", R.drawable.image2);
        myMusicList.add(mMusicData);

        mMusicData = new MusicData("DYNAMITE"," BTS","'Cause I-I-I'm in the stars tonight\n" +
                "So watch me bring the fire and set the night alight\n" +"\n" +
                "Shoes on, get up in the morn'\n" +
                "Cup of milk, let's rock and roll\n" +
                "King Kong, kick the drum, rolling on like a Rolling Stone\n" +
                "Sing song when I'm walking home\n" +
                "Jump up to the top, LeBron\n" +
                "Ding dong, call me on my phone\n" +
                "Ice tea and a game of ping pong, huh\n" +"\n" +
                "This is getting heavy\n" +
                "Can you hear the bass boom? I'm ready (woo hoo)\n" +
                "Life is sweet as honey\n" +
                "Yeah, this beat cha-ching like money, huh\n" +
                "Disco overload, I'm into that, I'm good to go\n" +
                "I'm diamond, you know I glow up\n" +
                "Hey, so let's go\n" + "\n" +
                "'Cause I-I-I'm in the stars tonight\n" +
                "So watch me bring the fire and set the night alight (hey)\n" +
                "Shining through the city with a little funk and soul\n" +
                "So I'ma light it up like dynamite, whoa oh oh\n" + "\n" +
                "Bring a friend, join the crowd\n" +
                "Whoever wanna come along\n" +
                "Word up, talk the talk\n" +
                "Just move like we off the wall\n" +
                "Day or night, the sky's alight\n" +
                "So we dance to the break of dawn\n" +
                "Ladies and gentlemen, I got the medicine\n" +
                "So you should keep ya eyes on the ball, huh\n" + "\n" +
                "This is getting heavy\n" +
                "Can you hear the bass boom? I'm ready (woo hoo)\n" +
                "Life is sweet as honey\n" +
                "Yeah, this beat cha-ching like money\n" +
                "Disco overload, I'm into that, I'm good to go\n" +
                "I'm diamond, you know I glow up\n" +
                "Let's go\n" + "\n" +
                "'Cause I-I-I'm in the stars tonight\n" +
                "So watch me bring the fire and set the night alight (hey)\n" +
                "Shining through the city with a little funk and soul\n" +
                "So I'ma light it up like dynamite, whoa oh oh\n" + "\n" +
                "Dy-na-na-na, na-na, na-na-na, na-na-na, life is dynamite\n" +
                "Dy-na-na-na, na-na, na-na-na, na-na-na, life is dynamite\n" +
                "Shining through the city with a little funk and soul\n" +
                "So I'ma light it up like dynamite, whoa oh oh\n" + "\n" +
                "Dy-na-na-na, na-na, na-na, ayy\n" +
                "Dy-na-na-na, na-na, na-na, ayy\n" +
                "Dy-na-na-na, na-na, na-na, ayy\n" +
                "Light it up like dynamite\n" + "\n" +
                "Dy-na-na-na, na-na, na-na, ayy\n" +
                "Dy-na-na-na, na-na, na-na, ayy\n" +
                "Dy-na-na-na, na-na, na-na, ayy\n" +
                "Light it up like dynamite\n" + "\n" +
                "'Cause I-I-I'm in the stars tonight\n" +
                "So watch me bring the fire and set the night alight\n" +
                "Shining through the city with a little funk and soul\n" +
                "So I'ma light it up like dynamite (this is ah)\n" +
                "'Cause I-I-I'm in the stars tonight\n" +
                "So watch me bring the fire and set the night alight (alight, oh)\n" +
                "Shining through the city with a little funk and soul\n" +
                "So I'ma light it up like dynamite, whoa (light it up like dynamite)\n" +
                "Dy-na-na-na, na-na, na-na-na, na-na-na, life is dynamite\n" +
                "Dy-na-na-na, na-na, na-na-na, na-na-na, life is dynamite\n" +
                "Shining through the city with a little funk and soul\n" +
                "So I'ma light it up like dynamite, whoa oh oh", R.drawable.image3);
        myMusicList.add(mMusicData);

        mMusicData = new MusicData("ALL THE KIDS ARE DEPRESSED"," Jermey Zucker","How long have you been smiling?\n" +
                "It seems like it's been too long\n" +
                "Some days I don't feel like trying\n" +
                "So what the fuck are you on\n" +
                "Whoa, ohh\n" + "\n" +
                "I think too much, we drink too much\n" +
                "Falling in love like it's just nothing\n" +
                "I want to know where do we go\n" +
                "When nothing's wrong\n" + "\n" +
                "'Cause all the kids are depressed\n" +
                "Nothing ever makes sense\n" +
                "I'm not feeling alright\n" +
                "Staying up 'til sunrise\n" +
                "And hoping shit is okay\n" +
                "Pretending we know things\n" +
                "I don't know what happened\n" +
                "My natural reaction is that we're scared\n" +
                "Ohh-oh-oh\n" +
                "Noo-oo-oo\n" +
                "Ohh-oh-oh...\n" + "\n" +
                "So I guess we're scared\n" +
                "Ohh-oh-oh, ohh-oh-oh\n" +
                "But I can't really keep lyin' (lyin')\n" +
                "'Cause I've been scared all along (all along)\n" +
                "I'm getting sick of sleeping in\n" +
                "While all my friends are popping pills, and\n" +
                "I don't think that they're wrong, woah, oh\n" +
                "I think too much, we drink too much\n" +
                "Falling apart like it's just nothing\n" +
                "I want to know, where do we go\n" +
                "When nothing's wrong\n" +
                "'Cause all the kids are depressed\n" +
                "Nothing ever makes sense\n" +
                "I'm not feeling alright\n" +
                "Staying up 'til sunrise\n" +
                "And hoping shit is okay\n" +
                "Pretending we know things\n" +
                "I don't know what happened\n" +
                "My natural reaction is that we're scared\n" +
                "Ohh-oh-oh\n" +
                "Noo-oo-oo\n" +
                "Ohh-oh-oh...\n" + "\n" +
                "So I guess we're scared\n" +
                "I won't deny it 'cause you saw what it was\n" +
                "I can't deny it if you won't give a fuck\n" +
                "So I'll throw it out\n" +
                "You know I am so in love", R.drawable.image4);
        myMusicList.add(mMusicData);

        mMusicData = new MusicData("SOPHIA"," Juke Ross","They don't know you like I do\n" +
                "I know that your heart burns true\n" +
                "Still they try and send their waves after you\n" +
                "When evening falls\n" +
                "I know where your demons crawl\n" +
                "Can't deny it, that you fight them face-on\n" + "\n" +
                "When all is done and said, you are on my mind and\n" +
                "Ignore their greasy eyes, cherish your all\n" +
                "While we grow still\n" + "\n" +
                "Sophia, oh\n" +
                "I might be gone tonight\n" +
                "But I'm never far from you, oh\n" +
                "Sophia\n" + "\n" +
                "Know I said goodbye, but I'll never forget your heart\n" +
                "My Sophia\n" +
                "Swear that I won't slip away\n" +
                "The essence of your heart will always stays safe within my lungs\n" +
                "And the blood in my veins\n" +
                "When the crowds are gone and we are old\n" +
                "By your side I rest bones, take our space in the grass\n" +
                "And watch 'til lilies grow\n" + "\n" +
                "That's when I'm on my knees\n" +
                "Can see the fall is from the trees\n" +
                "Just like the morning breeze\n" +
                "You know you pick me up with ease\n" + "\n" +
                "Sophia\n" +
                "I might be gone tonight\n" +
                "But I'm never far from you\n" +
                "Sophia\n" + "\n" +
                "Know I said goodbye, but I'll never forget your heart\n" +
                "My Sophia\n" +
                "Sophia\n" +
                "My Sophia\n" +
                "Sophia\n" +
                "My Sophia\n" + "\n" +
                "I might be gone tonight\n" +
                "But I'm never far from you\n" +
                "Sophia\n" +
                "I might be gone tonight\n" +
                "But I'm never far from you\n" +
                "Sophia\n" +
                "Know I said goodbye, but I'll never forget your heart\n" +
                "My Sophia",R.drawable.image5);
        myMusicList.add(mMusicData);

        mMusicData = new MusicData("BEAUTIFUL PEOPLE"," Ed Sheeran","We are, we are, we are\n" +"\n" +
                "L.A. on a Saturday night in the summer\n" +
                "Sundown and they all come out\n" +
                "Lamborginis and their rented Hummers\n" +
                "The party's on, so they're headin' downtown\n" +"\n" +
                "Everybody's lookin' for a come up\n" +
                "And they wanna know what you're about\n" +
                "Me in the middle with the one I'm lovin'\n" +
                "We're just tryna figure everything out\n" +"\n" +
                "We don't fit in well\n" +
                "'Cause we are just ourselves\n" +
                "I could use some help\n" +
                "Gettin' out of this conversation, yeah\n" +
                "You look stunning, dear\n" +
                "So don't ask that question here\n" +
                "This is my only fear, that we become (hey)\n" +
                "Beautiful people\n" +"\n" +
                "Drop top, designer clothes\n" +
                "Front row at fashion shows\n" +
                "\"What d'you do?\" and \"Who d'you know?\"\n" +
                "Inside the world of beautiful people\n" +"\n" +
                "Champagne and rolled-up notes\n" +
                "Prenups and broken homes\n" +
                "Surrounded, but still alone\n" +
                "Let's leave the party\n" +"\n" +
                "That's not who we are\n" +
                "(We are, we are, we are)\n" +
                "We are not beautiful\n" +
                "Yeah, that's not who we are\n" +
                "(We are, we are, we are)\n" +
                "We are not beautiful (beautiful)\n" + "\n" +
                "L.A. (mmm) drove for hours last night\n" +
                "And we made it nowhere (nowhere, nowhere)\n" +
                "I see stars in your eyes\n" +
                "When we're halfway there (all night)\n" +"\n" +
                "I'm not fazed by all them lights\n" +
                "And flashin' cameras\n" +
                "'Cause with my arms around you\n" +
                "There's no need to care\n" +"\n" +
                "We don't fit in well\n" +
                "We are just ourselves\n" +
                "I could use some help\n" +
                "Gettin' out of this conversation, yeah\n" +"\n" +
                "You look stunning, dear (ah)\n" +
                "So don't ask that question here\n" +
                "This is my only fear\n" +
                "That we become (hey)\n" +"\n" +
                "Beautiful people\n" +
                "Drop top, designer clothes\n" +
                "Front row at fashion shows\n" +
                "\"What d'you do?\" and \"Who d'you know?\"\n" +"\n" +
                "Inside the world of beautiful people\n" +
                "Champagne and rolled-up notes\n" +
                "Prenups and broken homes\n" +
                "Surrounded, but still alone\n" +
                "Let's leave the party\n" +"\n" +
                "That's not who we are\n" +
                "(We are, we are, we are)\n" +
                "We are not beautiful, yeah\n" +"\n" +
                "Yeah, that's not who we are\n" +
                "We are not beautiful (beautiful)\n" +"\n" +
                "We are, we are, we are\n" +
                "We are not beautiful",R.drawable.image6);

        myMusicList.add(mMusicData);

        Pdata Pdata= new Pdata (MainActivity.this, myMusicList);
        mRecyclerView.setAdapter(Pdata);
    }
}